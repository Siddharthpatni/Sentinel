# Sentinel — Build Kit README

Four files. Use them in this order.

---

## File 1 · `sentinel_antigravity_prompt.md`

**What it is:** the Phase 1 MVP build spec. Paste into a fresh Antigravity workspace to scaffold the gateway, SDK, dashboard, Docker stack, and CI from zero.

**When to use:** day one. Before you write any code.

**Output after using it:** a self-hostable LLM proxy with a working dashboard. Tracing only — no verification, no routing, no evals yet.

**Time estimate:** ~4 weeks of part-time work alongside coursework.

---

## File 2 · `sentinel_phase2_antigravity_prompt.md`

**What it is:** the Phase 2 build spec. Adds verification loops, multi-model routing, and the eval harness — the features that make Sentinel a differentiated product rather than another tracing tool. Also enforces the `docs/learn/` learning-notes folder.

**When to use:** after Phase 1 MVP is merged to `main` and CI is green. Open a **fresh** Antigravity session — do not continue from Phase 1.

**Output after using it:** Sentinel that can act on what it observes. Three new dashboard pages, three new subsystems, ~14 learning notes you've actually read.

**Time estimate:** ~5 weeks of part-time work.

---

## File 3 · `phase2_progress_tracker.md`

**What it is:** a living tracker for Phase 2 progress. Step-by-step table, deviation log, metrics snapshot, blocker log, agent-behaviour observations.

**When to use:** open the moment you start Phase 2. Update after every step the agent completes. Don't trust your memory — write commits and dates as they happen.

**Why it matters:** when you eventually write the Phase 3 prompt, this file tells you what actually got built versus what the Phase 2 spec promised. Those are never the same thing.

---

## File 4 · `phase3_wishlist_template.md`

**What it is:** a capture file for every "we should do this later" thought during Phase 2.

**When to use:** open it on day one of Phase 2 and keep it pinned. Append the moment an idea occurs — don't filter, don't wait for the perfect phrasing. Filter later.

**Why it matters:** this file is the **primary input** when you sit down to write the real Phase 3 prompt in ~6 weeks. Without it, you'll write Phase 3 from imagined needs rather than observed ones.

---

## The full sequence

```
Day 1                                      Week ~4                              Week ~9                          Week ~12
  │                                          │                                    │                                │
  ▼                                          ▼                                    ▼                                ▼
Paste File 1                          Phase 1 MVP on main             Phase 2 done, demo recorded         Phase 3 prompt written
into Antigravity                            │                                    │                          (from File 4 contents)
  │                                         │                                    │                                │
  │  ──── 4 weeks of building ────▶         │  ──── 5 weeks of building ────▶   │                                │
  │                                         │                                    │                                ▼
  │                                         │                                    │                          Paste Phase 3 prompt
  │                                  Open Files 3 & 4 here                       │                          into Antigravity
  │                                  Paste File 2 here                           │                                │
  │                                                                              │                                │
  └──────────────────────────────────────────┼────────────────────────────────────┼────────────────────────────────┘
                                             │                                    │
                                       Update File 3                      Review File 4
                                       after each step                    Cluster, prune, decide
                                       Append File 4                      what makes Phase 3 cut
                                       on every idea
```

## What you ship at the end of all four files

- A public GitHub repository: `sentinel` — production-grade architecture, real tests, CI, Docker
- A live demo URL (deploy on Fly.io, Railway, or a €5/month VPS)
- A 2-minute screen-capture demo video, linked in the README
- `docs/learn/` — your own study guide, written in your repo
- A blog series (3–5 posts) documenting the build journey on your portfolio site
- Concrete numbers from real benchmarks for your CV ("Reduced LLM costs by N% via policy routing on benchmark X. Caught M% of agent regressions in CI before deploy.")
- One specific story to tell in every interview from now on

## A note on the timeline

The 3 months on your original plan is roughly accurate if you can put in ~15 hours per week alongside your coursework. If you have a heavy semester, double it — better to ship a polished Sentinel in 6 months than a half-finished one in 3. Recruiters don't see the calendar, they see the artifact.

Don't be precious about it slipping. Be precious about it being good.
