# Sentinel — Phase 2 Antigravity Build Prompt

> Paste this entire document into a fresh Antigravity workspace pointed at the existing Sentinel repository. Phase 1 MVP must be on `main` and all CI gates green before starting. This prompt scopes Phase 2 only — verification loops, multi-model routing, and the eval harness. Audit logging and AI Act compliance come in Phase 3.

---

## 0. Mission for Phase 2

Sentinel can already observe LLM calls. Phase 2 makes it **act on what it observes**:

1. **Verification loops** — when a primary model produces an output, a configured "judge" model re-checks it. Agreements and disagreements are stored. Used to catch regressions, hallucinations, and silent-failure modes that don't throw HTTP errors.

2. **Multi-model routing** — a policy engine picks the cheapest model that meets a quality threshold for a given task class, with automatic fallback to a stronger model on failure or low confidence. Real measurable cost savings.

3. **Eval harness** — YAML-defined test cases run against any configured agent endpoint, on demand or in CI. Regression diffs between runs are surfaced in the dashboard. This is the feature that turns Sentinel from "an observability tool" into "a CI gate for AI products" — which is the differentiator vs Langfuse.

At the end of Phase 2 the dashboard has three new pages (`/verifications`, `/policies`, `/evals`) and the gateway has three new subsystems. The CI workflow in this repo can fail builds on eval regressions.

## 1. Non-negotiable constraints (inherited from Phase 1)

- All new code follows the Phase 1 stack and standards: Python 3.11, FastAPI, async-first, SQLAlchemy 2 async, Celery + Redis, PostgreSQL 16, Next.js 14, TypeScript strict, ruff, mypy strict.
- Every new feature ships with: typed code, unit tests, integration tests, structured logging, docs.
- New env vars added through `pydantic-settings` only. Update `.env.example`.
- Backwards compatible: existing Phase 1 endpoints (`/v1/chat/completions`, `/v1/messages`, `/api/traces/*`) keep their current contract exactly. No breaking changes to the SDK.
- All Alembic migrations are forward-only. Test rollback in a separate branch before committing.

## 2. New database tables

Add these in a single migration `002_phase_2.py`. Do not add fields not listed here.

**`verifications`** — one row per judge evaluation of a primary call.

| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| created_at | timestamptz default now() | indexed |
| trace_id | UUID FK traces.id | the primary call being verified |
| judge_trace_id | UUID FK traces.id | the judge's own call (also traced) |
| judge_model | text | e.g. `claude-sonnet-4-5` |
| verdict | text | `agree` / `disagree` / `uncertain` / `error` |
| confidence | numeric(4,3) | 0.000 – 1.000, nullable |
| reasoning | text | judge's explanation, nullable |
| rule_id | UUID FK verification_rules.id | which rule triggered this |

**`verification_rules`** — declarative rules for when to verify.

| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| project_id | UUID FK | |
| name | text | human label |
| match_jsonpath | text | JSONPath expression against request body; row applies when this matches |
| sample_rate | numeric(4,3) | 0.0 – 1.0; fraction of matching calls to verify |
| judge_model | text | |
| judge_prompt_template | text | Jinja2; receives `{{ request }}`, `{{ response }}` |
| enabled | bool default true | |

**`routing_policies`** — declarative routing rules.

| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| project_id | UUID FK | |
| name | text | |
| match_jsonpath | text | applies when request matches |
| candidates | jsonb | ordered list of `{model, max_cost_usd, max_latency_ms}` |
| fallback_on | jsonb | conditions triggering escalation: `{http_5xx: true, low_confidence: 0.6, ...}` |
| enabled | bool default true | |

**`evals`** — eval suite metadata.

| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| project_id | UUID FK | |
| name | text unique per project | |
| yaml_source | text | full YAML for reproducibility |
| created_at | timestamptz default now() | |

**`eval_runs`** — one row per execution of a suite.

| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| eval_id | UUID FK evals.id | |
| started_at | timestamptz | |
| finished_at | timestamptz nullable | |
| total | int | |
| passed | int | |
| failed | int | |
| triggered_by | text | `manual` / `ci` / `schedule` |
| git_sha | text nullable | populated when triggered from CI |

**`eval_cases`** — per-case result within a run.

| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| run_id | UUID FK eval_runs.id | |
| case_name | text | from YAML |
| input | jsonb | |
| expected | jsonb | |
| actual | jsonb | |
| passed | bool | |
| assertion_log | jsonb | per-assertion pass/fail details |
| trace_id | UUID FK traces.id nullable | the gateway call this case produced |

Indexes: `verifications(trace_id)`, `eval_cases(run_id, passed)`, `eval_runs(eval_id, started_at desc)`.

## 3. New repository layout

Add the following on top of the Phase 1 tree. Do not move or rename existing files.

```
gateway/app/
├── verification/
│   ├── __init__.py
│   ├── rules.py            # match logic, sampling
│   ├── judges.py           # judge prompt rendering, response parsing
│   └── orchestrator.py     # Celery task: enqueue-on-trace-write
├── routing/
│   ├── __init__.py
│   ├── policy.py           # match + candidate selection
│   ├── selector.py         # picks next model on fallback
│   └── middleware.py       # FastAPI dependency that wraps provider calls
├── evals/
│   ├── __init__.py
│   ├── parser.py           # YAML → pydantic models
│   ├── runner.py           # executes a suite, writes eval_runs + eval_cases
│   ├── assertions.py       # built-in assertion types
│   └── github_action.py    # entrypoint for CI
└── routes/
    ├── verifications.py    # GET /api/verifications, POST /api/verification-rules
    ├── policies.py         # CRUD for routing_policies
    └── evals.py            # POST /api/evals/{id}/run, GET /api/evals/{id}/runs/...

dashboard/app/
├── verifications/page.tsx
├── policies/page.tsx
├── evals/
│   ├── page.tsx                # suite list
│   ├── [id]/page.tsx           # run history for a suite
│   └── [id]/runs/[runId]/page.tsx  # detailed diff view

examples/
├── eval_suite_example.yaml
└── routing_policy_example.json
```

## 4. Subsystem specs

### 4.1 Verification loops

**Trigger flow:**
1. After a trace is persisted by the Phase 1 Celery worker, it emits a new Celery task `evaluate_trace(trace_id)`.
2. `orchestrator.py` loads enabled `verification_rules` for the trace's project, evaluates each rule's `match_jsonpath` against the request body, and rolls a random number against `sample_rate`.
3. For each matching, sampled rule, render the `judge_prompt_template` (Jinja2 sandboxed environment, never `unsafe`). Inputs: full request body, full response body.
4. Call the judge model **through Sentinel's own gateway** so the judge call is also a tracked trace. This is important — judge calls are real spend and must be observable.
5. Parse the judge response. Expected JSON shape (enforced):
   ```json
   {"verdict": "agree|disagree|uncertain", "confidence": 0.0-1.0, "reasoning": "..."}
   ```
   Use the OpenAI/Anthropic structured-output / JSON-mode features. On parse failure: `verdict = "error"`, store raw text in `reasoning`.
6. Insert a `verifications` row linking primary trace, judge trace, and verdict.

**Important constraints:**
- Judging is async and non-blocking — the original caller never waits.
- Never verify a verification (no infinite recursion). Tag judge calls with header `X-Sentinel-Judge: 1` and skip rule evaluation on traces carrying it.
- If `sample_rate = 0`, the rule is disabled but kept for history.
- Failure to verify is never an error to the primary caller. Log it, store a `verdict = "error"` row.

**Tests:**
- Unit: rule matching with various JSONPath expressions, sampling determinism with a seeded RNG, prompt rendering escapes correctly, judge response parsing.
- Integration: post a request through the gateway, assert exactly one verification row appears with `verdict in {agree, disagree, uncertain}`, assert the judge call also has a `traces` row tagged as a judge.

### 4.2 Multi-model routing

**Flow:**
1. Incoming `/v1/chat/completions` request enters routing middleware *before* the existing provider adapter.
2. Middleware loads enabled `routing_policies` for the project, picks the first whose `match_jsonpath` matches. If none, behaviour is identical to Phase 1 — request goes to the model the caller named.
3. If a policy matches, the requested model is **overridden** by the first candidate in `candidates`. Add response header `X-Sentinel-Routed-From: <original_model>` so callers can see what happened.
4. The call proceeds. On any condition in `fallback_on` being true (HTTP 5xx, timeout, judge verdict `disagree` within a configurable window, or response confidence below threshold), the middleware retries with the next candidate.
5. Each attempt is its own trace. Add a `route_attempt` column to traces? **No** — store this in `traces.request_body` under a `_sentinel.route` key to avoid a Phase 1 schema break.

**Constraints:**
- Maximum 3 fallback attempts per request, hard-coded.
- Total latency budget is the sum of per-candidate `max_latency_ms`. Stop early if exceeded.
- Streaming requests bypass routing fallback after the first chunk is sent (you can't un-stream). Log a `route_locked` event.
- Routing is opt-in per project — no policies means no routing.

**Tests:**
- Unit: candidate selection, fallback condition evaluation, latency budget.
- Integration: mock provider returning 500 → assert second candidate is called and succeeds, assert two trace rows linked by `_sentinel.route.parent_request_id`.

### 4.3 Eval harness

**YAML format** (validated by pydantic):

```yaml
name: customer-support-quality
target:
  endpoint: /v1/chat/completions
  model: gpt-4o-mini
cases:
  - name: refund-tone
    input:
      messages:
        - role: user
          content: I want a refund for order #1234.
    assertions:
      - type: contains
        path: $.choices[0].message.content
        value: "refund"
        case_sensitive: false
      - type: not_contains
        value: "I cannot help"
      - type: max_latency_ms
        value: 3000
      - type: llm_judge
        judge_model: claude-sonnet-4-5
        criterion: Response is empathetic and offers a clear next step.
        passing_confidence: 0.7
```

**Built-in assertion types:**
- `contains` / `not_contains` — substring in JSONPath-extracted value
- `equals` / `not_equals` — exact match on extracted value
- `regex` — pattern match
- `max_latency_ms` / `max_cost_usd` — performance bounds
- `llm_judge` — judge call with pass/fail verdict
- `json_schema` — validate response against a JSON schema

**Runner flow:**
1. Load YAML, validate, persist as `evals` row (upsert on `name`).
2. Create `eval_runs` row, set `started_at`, `triggered_by`, `git_sha`.
3. For each case, fire request through the gateway, capture the resulting trace, run assertions.
4. Write an `eval_cases` row per case with `passed`, `assertion_log`, `trace_id`.
5. On completion update `eval_runs.finished_at`, `total`, `passed`, `failed`.

**CI integration:**
- `gateway/app/evals/github_action.py` is callable as `python -m app.evals.github_action --suite <name> --gateway-url <url> --fail-on-regression`.
- Exit code 0 if pass count >= previous run's pass count. Exit code 1 otherwise.
- Outputs a markdown summary suitable for `$GITHUB_STEP_SUMMARY`.

**Tests:**
- Unit: YAML parser, each assertion type, regression detection.
- Integration: run a 3-case suite against a mocked gateway, assert correct rows written.

## 5. Dashboard pages

Three new pages, server components by default, shadcn primitives only.

**`/verifications`**
- Header KPIs: 24h agreement rate, total verifications, top disagreeing model pairs.
- Table: time, primary model, judge model, verdict (coloured badge), confidence, click → opens a diff modal showing primary response vs judge reasoning side-by-side.
- Filters: by rule, by verdict, by date range.

**`/policies`**
- List of routing policies as cards.
- "Create policy" opens a form with: name, JSONPath matcher (with live tester against recent traces), candidate models picker, fallback condition checkboxes.
- Per policy, a sparkline showing fallback rate over last 7 days.

**`/evals`**
- List view: suite name, last run status (pass/fail badge), pass rate trend (Recharts line, last 10 runs), "Run now" button.
- Detail (`/evals/[id]`): run history table with diff column ("+2 passing, -1 passing vs previous").
- Run detail (`/evals/[id]/runs/[runId]`): per-case results table, expandable rows show full request/response/assertions, link to the underlying trace.

Add nav links in the existing layout. Do not redesign the layout.

## 6. Build order (15 steps, in order)

After each step, run the verification commands and wait for "go" before proceeding. Same RAM discipline as the Phase 1 transitions: git-diff-driven re-reads only, 3-file working set cap.

1. **Migration 002.** Create all five new tables and indexes. Test migration up/down on a scratch DB.
2. **Verification rules model + CRUD route.** `POST /api/verification-rules`, list, enable/disable. Tests.
3. **Judge module.** Prompt rendering with sandboxed Jinja2, structured-output parsing, error handling. Tests with `respx`-mocked providers.
4. **Verification orchestrator Celery task.** Listens for trace-persisted events (use Celery chain from the existing `persist_trace`). Tests for sampling, recursion prevention, judge trace tagging.
5. **`/api/verifications` GET endpoint** + pagination. Tests.
6. **Dashboard `/verifications` page.** Table, filters, diff modal. Vitest component tests.
7. **Routing policy model + CRUD route.** Tests.
8. **Routing middleware.** Match → candidate selection → fallback orchestration. Streaming-bypass logic. Tests with mocked providers returning 500/timeout.
9. **Dashboard `/policies` page.** Card list, create form with live JSONPath tester.
10. **Eval YAML parser + assertion engine.** All 7 assertion types. Tests for each.
11. **Eval runner.** Suite execution, eval_runs/eval_cases persistence. Tests.
12. **`/api/evals/*` endpoints.** Run, history, run detail. Tests.
13. **Dashboard `/evals/*` pages.** Suite list, run history, run detail with diff.
14. **CI integration script.** `github_action.py` entrypoint, regression detection, markdown summary. Add a `eval.yml` workflow template to `.github/workflows/`.
15. **Docs + README update.** Update README with three new sections. Add `docs/verifications.md`, `docs/routing.md`, `docs/evals.md`.

## 7. The learning notes requirement (READ CAREFULLY)

This is a hard requirement, not optional.

Throughout Phase 2, maintain a `docs/learn/` folder. **Every time the agent uses a concept, pattern, library, or technique that a mid-career developer might not be deeply familiar with, write a short note about it.** This turns the build process into structured learning material.

The agent must produce these notes *while* building the relevant step, not as a final pass. A note is created the first time a topic appears.

**Folder structure:**

```
docs/learn/
├── README.md                         # index with one-line description per note
├── 001-jsonpath-expressions.md
├── 002-jinja2-sandboxed-environments.md
├── 003-llm-structured-output.md
├── 004-celery-task-chaining.md
├── 005-jsonb-indexing-postgres.md
├── 006-fastapi-dependency-injection.md
├── 007-server-sent-events-streaming.md
├── 008-cursor-based-pagination.md
├── 009-react-server-components-vs-client.md
├── 010-recharts-composability.md
├── 011-pydantic-discriminated-unions.md
├── 012-pytest-fixtures-async.md
├── 013-github-actions-job-summaries.md
└── 014-conventional-commits-and-semver.md
```

The list above is the **minimum** — Antigravity should add more as it encounters new concepts. If the agent uses something not on the list (e.g. SQLAlchemy `Mapped` syntax, Pydantic v2 `Annotated` types, Next.js `generateStaticParams`), it adds a note.

**Required structure of each note** (≤ 300 words, no fluff):

```markdown
# <Topic name>

## What it is
One paragraph, plain English.

## Why we use it in Sentinel
Where it appears in this codebase, with file paths.

## Minimal working example
A 10–20 line code snippet, runnable in isolation.

## The two or three gotchas
The specific things that bite people the first time they use this.

## Where to learn more
- Official docs link
- One high-signal blog post or tutorial (no listicles, no Medium "10 things")
- (Optional) one video, only if it's truly the best resource
```

**Index file (`docs/learn/README.md`):** one line per note, grouped by category (Backend / Frontend / Infra / Testing / Process). The agent updates this every time it adds a note.

**Constraints:**
- Never write "see official docs" without a specific URL.
- Never inflate to hit a word count. Short and dense is the goal.
- Code snippets must be tested — if it appears in a note, it must run.
- No AI-flavoured prose ("In today's fast-paced world…"). Direct technical writing only.

## 8. Acceptance criteria

Phase 2 is complete when **all** of these are true:

- Migration 002 applies cleanly. All Phase 1 tests still pass.
- A request to the gateway that matches a verification rule produces, within 10 seconds, a `verifications` row with a non-error verdict and a linked judge trace.
- A request matching a routing policy is routed to the first candidate; injected 500 from the first candidate causes a second attempt against the second candidate, surfaced as two linked traces.
- `python -m app.evals.github_action --suite customer-support-quality` runs the example suite end-to-end against a local gateway and returns exit code 0.
- All three new dashboard pages render correctly with real data and pass Vitest component tests.
- `docs/learn/` contains at least the 14 baseline notes, all following the required structure, all with working code snippets.
- CI passes: lint, typecheck, backend tests with coverage ≥ 80% on new modules, frontend tests, docker build.
- README has a "Phase 2 features" section with one paragraph per subsystem and a screenshot per new dashboard page.

## 9. Out of scope for Phase 2

The agent must not start any of these — they are Phase 3:

- AI Act audit log, immutable storage, cryptographic chaining
- Risk-tier tagging
- Email/webhook alerting
- Cost charts on the home page (the existing Phase 1 KPI cards are sufficient)
- Real user authentication / SSO / billing
- Custom assertion types beyond the 7 listed
- Distributed tracing (OpenTelemetry export)
- Multi-region deployment

If the agent finds itself working on any of these, stop and re-read this section.

## 10. Phase 3 prompt placeholder

When Phase 2 is merged to `main`, start a new Antigravity session with the Phase 3 prompt (to be written when Phase 2 is done). Do not pre-emptively design for Phase 3.

---

## Kickoff instruction for Antigravity

Reply only with:

```
Phase 1 verification:
<list of green CI gates on main, from `git log` and `gh run list`>

Phase 2 plan acknowledgement:
- 5 new tables: <list>
- 3 new subsystems: <list>
- 3 new dashboard pages: <list>
- Learning notes folder: docs/learn/ with minimum 14 notes
- Out-of-scope items understood: <list>

Step 1 file plan:
Files to create: <list>
Files to modify: <list>
Files to read first: <list>
New dependencies: <list or "none">

Awaiting "go" to begin Step 1.
```

Do not start coding until I reply "go".
