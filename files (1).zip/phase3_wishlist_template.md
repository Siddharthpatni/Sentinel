# Sentinel — Phase 3 Wishlist

> Capture every "we should do this later" thought during Phase 2. This file is the **primary input** for writing the Phase 3 Antigravity prompt. Don't trust memory — write it down the moment it occurs to you.

**Created:** _<date>_
**Phase 2 status when last updated:** _<step number>_

---

## How to use this file

1. While building Phase 2, every time you (or the agent) think "we should X later," append it to the relevant section below.
2. Don't filter at capture time — capture everything, filter later. A bad idea written down is better than a good idea forgotten.
3. Use the format: **What** (one line) · **Why** (one line) · **Trigger** (the moment that made you think of it).
4. When Phase 2 is done, review this file, group related items, and use it as the source for the Phase 3 spec.

---

## Already-locked Phase 3 scope (from original 3-month plan)

These were promised in the Phase 1 spec as Phase 3 work. They go in regardless.

- [ ] Immutable AI Act audit log (append-only, cryptographic chaining)
- [ ] JSONL export per project per date range
- [ ] Configurable retention policies
- [ ] Per-trace risk-tier tagging (minimal / limited / high / unacceptable) driven by a rules file
- [ ] `/audit` dashboard page with export controls
- [ ] Cost charts on home page (Recharts area chart, last 30 days)
- [ ] Eval-trend lines on `/evals`
- [ ] Email alerting via SMTP on configurable rules (cost spike, error rate, eval regression)
- [ ] `docs/ai-act.md` mapping Sentinel features to AI Act articles

---

## New ideas surfaced during Phase 2

### Observability of Sentinel itself

_(Things you'll need to debug Sentinel in production)_

- **What:** _<one line>_
  **Why:** _<one line>_
  **Trigger:** _<when this idea hit you>_

### Schema improvements

_(Columns you wish you'd added, indexes that would help, denormalisations worth doing)_

- 

### Verification subsystem follow-ups

_(Things the verification feature exposed but didn't solve)_

- 

### Routing subsystem follow-ups

- 

### Eval subsystem follow-ups

- 

### Dashboard / UX improvements

- 

### Performance issues observed

_(Latency spikes, slow queries, N+1s, anything that felt sluggish)_

- 

### Developer experience pain points

_(Things that slowed you down repeatedly while building)_

- 

### Documentation gaps

_(Stuff you had to figure out twice because you didn't write it down)_

- 

### Security concerns deferred

_(Things you skipped on purpose, want to come back to)_

- 

---

## Architectural decisions to revisit

When you hit a decision point and pick option A but think "B might have been better," log it here. Phase 3 may be the right moment to revisit.

| Date | Decision made | Alternative considered | Why might want to revisit |
|------|---------------|------------------------|---------------------------|
| | | | |

---

## Dependencies you wish you'd added

Libraries you reached for but decided not to add to keep Phase 2 lean. Phase 3 may justify them.

- 

---

## Features users (or you, as a user) asked for

If you demo Phase 2 to anyone — friends, fellow students, recruiters at meetups — log their reactions and feature requests here. Real feedback beats imagined feedback.

| Date | Who | What they wanted | How strongly |
|------|-----|------------------|--------------|
| | | | |

---

## Things that turned out to be more important than expected

- 

## Things that turned out to be less important than expected

- 

---

## Pre-Phase-3 grooming checklist

Before writing the Phase 3 prompt, do these:

- [ ] Read this entire file end-to-end
- [ ] Cluster related items into themes
- [ ] Drop items that no longer matter
- [ ] For each remaining cluster, decide: Phase 3? Phase 4? Never?
- [ ] Sketch the Phase 3 prompt structure (mission, constraints, tables, subsystems, build order, acceptance criteria — same shape as Phase 2 prompt)
- [ ] Run the resulting wishlist by someone technical for sanity check
- [ ] Then, and only then, write the Phase 3 Antigravity prompt
