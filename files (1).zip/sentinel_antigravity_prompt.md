# Sentinel — Agentic IDE Build Prompt (Month 1 MVP)

> Paste this entire document into Antigravity (or Cursor / Claude Code / Windsurf) as the initial task. It scopes the work to the **Month 1 MVP** so the agent doesn't try to one-shot the whole product. After MVP is green, append the Month 2 and Month 3 prompts (provided at the end).

---

## 1. Mission

Build **Sentinel**, an open-source, self-hostable reliability and observability platform for LLM agents. Sentinel sits as a drop-in proxy between an application and any LLM provider (OpenAI, Anthropic, Gemini, OpenRouter), logs every request and response, tracks cost and latency per call, and exposes a dashboard for inspecting traces.

This prompt covers **Phase 1 (MVP) only**. Do not build verification loops, routing policies, eval harnesses, or AI-Act audit modules yet — those come in Phase 2 and Phase 3.

The end-state of Phase 1 is: a developer can `pip install sentinel-sdk`, change one line of their OpenAI/Anthropic client setup to point at Sentinel's gateway, and immediately see every LLM call appear in a live dashboard with cost, latency, model, prompt, and response.

## 2. Non-negotiable constraints

- **Self-hostable.** Single `docker compose up` must start the entire stack on a fresh machine.
- **OpenAI-compatible API surface** on the gateway so existing SDKs work with a base-URL swap.
- **Async-first.** Every I/O path uses async; trace writes are non-blocking via a queue.
- **Production hygiene from day one**: typed code, tests, structured logging, `.env`-based config, no secrets in repo, pre-commit hooks.
- **No mocked LLM calls in shipped code.** Mocks live in tests only.

## 3. Tech stack (do not substitute)

| Layer | Choice |
|---|---|
| Gateway / API | Python 3.11, FastAPI, Uvicorn, Pydantic v2, httpx |
| Async jobs | Celery + Redis |
| Database | PostgreSQL 16 via SQLAlchemy 2 (async) + Alembic migrations |
| Frontend | Next.js 14 (App Router), TypeScript, Tailwind, shadcn/ui, Recharts |
| Containerisation | Docker, docker-compose |
| Testing | pytest + pytest-asyncio (backend), Vitest + Playwright (frontend) |
| Tooling | ruff, mypy (strict), Prettier, ESLint |
| CI | GitHub Actions: lint → typecheck → test → docker build |

## 4. Repository layout

```
sentinel/
├── docker-compose.yml
├── README.md
├── .env.example
├── .github/workflows/ci.yml
├── gateway/                 # FastAPI proxy + ingest API
│   ├── app/
│   │   ├── main.py
│   │   ├── config.py
│   │   ├── routes/
│   │   │   ├── openai_compat.py    # POST /v1/chat/completions etc.
│   │   │   ├── anthropic_compat.py # POST /v1/messages
│   │   │   ├── traces.py           # GET /api/traces, GET /api/traces/{id}
│   │   │   └── health.py
│   │   ├── providers/              # Provider adapters
│   │   │   ├── base.py
│   │   │   ├── openai.py
│   │   │   ├── anthropic.py
│   │   │   └── openrouter.py
│   │   ├── tracing/
│   │   │   ├── schema.py           # Pydantic models for a Trace
│   │   │   ├── recorder.py         # Captures req/resp, enqueues persist job
│   │   │   └── cost.py             # Token → USD per model
│   │   ├── db/
│   │   │   ├── models.py
│   │   │   ├── session.py
│   │   │   └── migrations/
│   │   └── workers/
│   │       └── persist_trace.py    # Celery task
│   ├── tests/
│   └── pyproject.toml
├── sdk/                      # `sentinel-sdk` Python package
│   ├── sentinel/
│   │   ├── __init__.py
│   │   └── client.py               # Thin wrapper exposing OpenAI/Anthropic clients pointed at gateway
│   ├── tests/
│   └── pyproject.toml
├── dashboard/                # Next.js app
│   ├── app/
│   │   ├── page.tsx                # Trace list
│   │   ├── traces/[id]/page.tsx    # Trace detail
│   │   └── layout.tsx
│   ├── components/
│   │   ├── trace-table.tsx
│   │   ├── cost-chart.tsx
│   │   └── ui/                     # shadcn primitives
│   ├── lib/api.ts                  # Fetches from gateway
│   └── package.json
└── docs/
    ├── architecture.md
    └── quickstart.md
```

## 5. Data model (PostgreSQL)

Create exactly these tables in the first Alembic migration. Do not add more in Phase 1.

**`traces`** — one row per LLM call.

| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| created_at | timestamptz default now() | indexed |
| provider | text | `openai` / `anthropic` / `openrouter` |
| model | text | e.g. `gpt-4o-mini` |
| endpoint | text | e.g. `/v1/chat/completions` |
| request_body | jsonb | full request as received |
| response_body | jsonb | full response from provider |
| prompt_tokens | int | nullable |
| completion_tokens | int | nullable |
| total_tokens | int | generated |
| cost_usd | numeric(12,6) | nullable; computed from `cost.py` table |
| latency_ms | int | wall-clock measured at gateway |
| status_code | int | upstream HTTP status |
| error | text | nullable; populated on failure |
| project_id | UUID | FK to projects |

**`projects`** — multi-tenant boundary (one is auto-seeded for MVP).

| Column | Type |
|---|---|
| id | UUID PK |
| name | text |
| api_key | text unique | used by SDK callers |
| created_at | timestamptz |

Index `traces` on `(project_id, created_at desc)`.

## 6. Request flow (the critical path)

1. Caller sends `POST /v1/chat/completions` to the gateway with header `Authorization: Bearer <sentinel-api-key>`.
2. Gateway validates the key against `projects.api_key`.
3. Gateway records `t_start`, forwards the request to the real provider using httpx with the **provider's own key from `.env`** (`OPENAI_API_KEY`, etc.).
4. Gateway receives the response, records `t_end`, computes `latency_ms`.
5. Gateway computes cost from `prompt_tokens`/`completion_tokens` × the per-model price table in `cost.py`.
6. Gateway returns the upstream response **verbatim** to the caller (byte-for-byte compatible — this is non-negotiable for SDK compatibility).
7. **After** returning, the gateway enqueues a Celery task to persist the trace. Persistence must never block the response.
8. Worker writes the row to PostgreSQL.

Streaming responses (`stream: true`) must also work: tee the SSE chunks to both the client and a buffer; persist the assembled buffer after the stream closes.

## 7. Dashboard (Next.js)

Two pages, no more, in Phase 1:

**`/` — Trace list**
- Server component, fetches from gateway `GET /api/traces?limit=50&cursor=...`
- Columns: time, model, tokens (prompt/completion), cost, latency, status (green/red dot)
- Cursor-based pagination
- Header strip: 24h total cost, 24h total calls, 24h avg latency (small Recharts sparkline)

**`/traces/[id]` — Trace detail**
- Full request JSON and response JSON in collapsible viewers (use a JSON tree component)
- Metadata sidebar: model, provider, tokens, cost, latency, timestamps

Styling: Tailwind + shadcn defaults, dark mode by default. Do not invent custom colour schemes. Use the shadcn `Card`, `Table`, `Badge`, `Tabs` primitives.

## 8. SDK (`sdk/`)

The SDK is intentionally thin. Its job is to give users a one-line swap:

```python
from sentinel import OpenAI  # drop-in replacement

client = OpenAI(api_key="sk-sentinel-...")  # talks to gateway, not api.openai.com
client.chat.completions.create(model="gpt-4o-mini", messages=[...])
```

Internally it just instantiates the real `openai.OpenAI` with `base_url=os.environ["SENTINEL_GATEWAY_URL"]`. Same pattern for `Anthropic`. No custom transport logic — keep it under 100 lines.

## 9. Build order (follow this sequence)

Execute as discrete, reviewable steps. After each step, confirm tests pass before moving on.

1. **Scaffold the monorepo.** Create folder structure, `pyproject.toml` files, `package.json`, `.env.example`, `.gitignore`, `README.md`, pre-commit config, ruff + mypy + ESLint configs.
2. **docker-compose.** Services: `postgres`, `redis`, `gateway`, `worker`, `dashboard`. Healthchecks on db and redis. Gateway depends_on healthy db.
3. **Database layer.** SQLAlchemy models, Alembic init, first migration. Seed script creates a default project with a known API key.
4. **Provider adapter for OpenAI.** httpx-based, async, supports streaming. Unit tests with `respx` mocking httpx.
5. **Gateway `/v1/chat/completions` route.** Implements the request flow in section 6. Integration test using `respx`: assert response passthrough is byte-identical to upstream.
6. **Tracing recorder + Celery worker.** Enqueue on response, persist to DB. Test that a request produces exactly one row with correct fields populated.
7. **Cost table.** Static dict of model → (prompt $/Mtok, completion $/Mtok). Cover `gpt-4o`, `gpt-4o-mini`, `claude-sonnet-4-5`, `claude-haiku-4-5`, `gemini-2.5-pro`, `gemini-2.5-flash`. Test cost computation.
8. **Anthropic adapter + `/v1/messages` route.** Same pattern as OpenAI.
9. **`/api/traces` endpoints.** List with cursor pagination + detail by id. Pydantic response models.
10. **SDK package.** Implement `OpenAI` and `Anthropic` shims. Publishable `pyproject.toml`.
11. **Dashboard scaffold.** Next.js app, Tailwind + shadcn init, layout, dark mode.
12. **Trace list page.** Server component, fetches and renders the table with header KPIs.
13. **Trace detail page.** JSON viewers, metadata sidebar.
14. **GitHub Actions CI.** lint → typecheck → test → docker build for both gateway and dashboard.
15. **README + quickstart.** A user clones, copies `.env.example` to `.env`, fills `OPENAI_API_KEY`, runs `docker compose up`, opens `localhost:3000`, runs a sample script from `examples/`, and sees the call appear within 2 seconds.

## 10. Acceptance criteria for the MVP

The Phase 1 deliverable is complete when **all** of these are true:

- `docker compose up` on a clean machine boots the full stack with no manual steps beyond editing `.env`.
- The example script in `examples/hello_openai.py` makes a real OpenAI call through the gateway, returns a valid completion, and the call appears in the dashboard within 2 seconds.
- Streaming (`stream=True`) works end-to-end and is logged correctly.
- Cost in USD is computed and stored for every successful call.
- Anthropic calls work via `/v1/messages`.
- Trace list paginates past 100 traces without UI jank.
- All tests pass in CI. Coverage report attached. mypy strict passes. ruff passes.
- README has: project description, screenshot of dashboard, 5-line quickstart, architecture diagram (Mermaid is fine).

## 11. Coding standards

- Python: PEP 8 via ruff, type hints on every public function, mypy strict, no `Any` without justification comment.
- TypeScript: strict mode, no `any`, named exports, server components by default in Next.js.
- Commits: Conventional Commits (`feat:`, `fix:`, `chore:`...).
- Every PR-sized step opens with: what changed, why, how it was tested.
- Logging: structured JSON via `structlog` in Python. No `print`. Frontend uses `console.error` only in error boundaries.
- Secrets: only via env vars, loaded through `pydantic-settings`. Never log them.
- Do not introduce dependencies not listed in section 3 without flagging first.

## 12. What is explicitly out of scope for Phase 1

Reject the temptation to build any of these now — they go in Phase 2 and 3:

- Verification loops / judge-model double-checking
- Multi-model routing or fallback policies
- Eval harness, YAML test definitions, regression diffs
- GitHub Actions integration for evals
- AI Act audit log, immutable export, risk-tier tagging
- Alerting, webhooks
- Real auth (the project API key is enough for MVP — no user accounts, no SSO)
- Billing, plans, quotas

If the agent finds itself writing code in any of these areas, stop and revisit this section.

## 13. After MVP — Phase 2 and Phase 3 prompts

Once the MVP is green and merged to `main`, start a new Antigravity session and prompt it with:

> Phase 2 of Sentinel. The Phase 1 MVP from `sentinel_antigravity_prompt.md` is complete and on `main`. Now add: (a) a verification loop subsystem where a configured "judge" model re-evaluates outputs flagged by rules and stores agreement/disagreement; (b) a routing policy engine that picks the cheapest model meeting a per-task quality threshold with automatic fallback; (c) an eval harness reading YAML test files, running them against any configured agent endpoint, storing results, and exposing regression diffs between runs. Maintain the constraints, stack, and standards from Phase 1. Add new tables `evals`, `eval_runs`, `eval_cases`, `routing_policies`, `verifications` — write the Alembic migration. Extend the dashboard with `/evals` and `/policies` pages. Same acceptance-criteria-first discipline.

> Phase 3 of Sentinel. Phases 1 and 2 are on `main`. Add: (a) an immutable AI Act audit log — append-only table with cryptographic chaining, JSONL export per project per date range, configurable retention; (b) per-trace risk-tier tagging (minimal/limited/high/unacceptable) driven by a rules file; (c) a `/audit` dashboard page with export controls; (d) polish — cost charts on the home page (Recharts area chart, last 30 days), eval-trend lines, basic email alerting via SMTP on configurable rules (cost spike, error rate, eval regression). Write a `docs/ai-act.md` mapping each Sentinel feature to the relevant Article. Same standards.

---

## How to use this prompt

1. Open Antigravity (or your agentic IDE of choice).
2. Create a new workspace called `sentinel`.
3. Paste this entire document as the initial task.
4. Tell the agent: **"Execute section 9 step by step. After each step, run the tests, show me the diff, and wait for confirmation before continuing."** That last clause matters — without it, agentic IDEs tend to barrel through and accumulate silent mistakes.
5. Keep a separate scratch file for design decisions you make mid-build (model choices, naming changes). Feed it back into the prompt for Phase 2.

When MVP is done, record a 2-minute screen capture of the quickstart flow. That video is what you link from your CV.
