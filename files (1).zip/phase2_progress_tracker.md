# Sentinel Phase 2 — Progress Tracker

> Living document. Update as each step lands. The goal: when Phase 3 is written, this file is the ground truth for what was actually built vs what the spec promised.

**Started:** _<date>_
**Target completion:** _<date>_
**Current step:** _<number / name>_

---

## Step status

| # | Step | Status | Commit | Date | Notes |
|---|------|--------|--------|------|-------|
| 1 | Migration 002 (5 new tables) | ☐ | | | |
| 2 | Verification rules model + CRUD | ☐ | | | |
| 3 | Judge module (Jinja2 + structured output) | ☐ | | | |
| 4 | Verification orchestrator Celery task | ☐ | | | |
| 5 | `/api/verifications` GET endpoint | ☐ | | | |
| 6 | Dashboard `/verifications` page | ☐ | | | |
| 7 | Routing policy model + CRUD | ☐ | | | |
| 8 | Routing middleware + fallback | ☐ | | | |
| 9 | Dashboard `/policies` page | ☐ | | | |
| 10 | Eval YAML parser + assertion engine | ☐ | | | |
| 11 | Eval runner | ☐ | | | |
| 12 | `/api/evals/*` endpoints | ☐ | | | |
| 13 | Dashboard `/evals/*` pages | ☐ | | | |
| 14 | CI integration script | ☐ | | | |
| 15 | Docs + README update | ☐ | | | |

Statuses: ☐ not started · 🔄 in progress · ⏸ blocked · ✓ done

---

## Deviations from spec

Every time you change something from the Phase 2 prompt — even small — record it here. Future-you in Phase 3 needs this.

| Date | What changed | Why | Spec section |
|------|--------------|-----|--------------|
| | | | |

Examples of what to log:
- Added a column not in the original schema
- Renamed an endpoint
- Changed the verdict enum values
- Replaced a library
- Skipped a planned test because it duplicated another

---

## Metrics snapshot (update weekly)

| Date | LOC backend | LOC frontend | Test coverage | CI duration | Open TODOs |
|------|-------------|--------------|---------------|-------------|------------|
| | | | | | |

Run from repo root:
```bash
# LOC
tokei gateway/app sdk/sentinel dashboard/app dashboard/components
# Coverage
pytest gateway/tests --cov=app --cov-report=term | tail -3
# TODO count
grep -rn "TODO\|FIXME" gateway/app sdk/sentinel dashboard/app dashboard/components | wc -l
```

---

## Blockers log

When something stalls a step for > 4 hours, write it here. If it resolves, mark resolved. If you give up and work around it, record the workaround.

| Date opened | Step | Blocker | Resolved? | Resolution / workaround |
|-------------|------|---------|-----------|-------------------------|
| | | | | |

---

## Things the agent did well

Track patterns worth reusing in Phase 3 prompts.

- _e.g. "Asked before adding a new dependency — kept this in Phase 3 prompt"_
- 

---

## Things the agent did badly

Track patterns to explicitly forbid in Phase 3 prompts.

- _e.g. "Built a custom JSON tree viewer despite spec saying use react-json-view-lite"_
- 

---

## Test results history

After each step's verification, paste the one-line summary. Useful for spotting flaky tests over time.

```
Step 1: 47 passed, 0 failed, 0 skipped — coverage 91%
Step 2: 
...
```

---

## Demo-readiness checklist

Tick when ready to record the Phase 2 demo video.

- [ ] All 15 steps committed to `main`
- [ ] CI green on `main`
- [ ] All learning notes written and indexed
- [ ] Three new dashboard pages screenshot-ready
- [ ] Example verification rule, routing policy, and eval suite seeded in default project
- [ ] `docker compose up` on a fresh clone works end-to-end
- [ ] Quickstart in README still accurate
- [ ] 2-minute demo script written

---

## Sign-off

Phase 2 is considered done when:
- [ ] All acceptance criteria from section 8 of the Phase 2 prompt are met
- [ ] This tracker is fully filled in
- [ ] `docs/phase3-wishlist.md` has at least 5 substantive entries
- [ ] Demo video recorded and linked in README

_<signature line — date you closed Phase 2>_
